﻿namespace Placement_Preparation.Models
{
    public class ButtonModel
    {
        public string Title { get; set; }
        public string Url { get; set; }

    }
}
